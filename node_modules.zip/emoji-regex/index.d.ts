declare module 'emoji-regex' {
    function emojiRegex(): RegExp;

    export default emojiRegex;
}
