# Deployment Steps
Add tests
npm test
Update README
Add and commit all changes
Manually bumb version number in package.json
Update HISTORY
gulp
git add -A
git commit -m "vX.X.X"
git tag vX.X.X
git push && git push --tags
npm publish